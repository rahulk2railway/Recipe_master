export class Credits {
  name: string;
  type: string;
}
