import { Components } from './components.model';

export class Sections {
  components: Array<Components>;
  name: string;
  position: number;
}
