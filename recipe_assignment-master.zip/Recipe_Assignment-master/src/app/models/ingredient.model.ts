export class Ingredient {
  id: number;
  name: string;
  display_singular: string;
  display_plural: string;
  created_at: Date;
  updated_at: Date;
}
