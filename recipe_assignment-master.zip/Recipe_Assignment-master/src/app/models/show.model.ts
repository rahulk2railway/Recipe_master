export class Show {
  id: number;
  name: string;
}
