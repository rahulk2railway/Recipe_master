export class UserRating {
  count_negative: number;
  score: number;
  count_positive: number;
}
