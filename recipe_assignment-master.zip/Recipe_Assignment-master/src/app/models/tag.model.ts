export class Tag {
  type: string;
  id: number;
  name: string;
  display_name: string;
}
