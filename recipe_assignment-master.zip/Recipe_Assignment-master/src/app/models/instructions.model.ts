export class Instructions {
  display_text: string;
  position: number;
  start_time: number;
  end_time: number;
  temperature: number;
  appliance: number;
  id: number;
}
