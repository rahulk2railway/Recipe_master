import { Unit } from './unit.model';
export class Measurements {
  id: number;
  quantity: number;
  unit: Unit;
}
