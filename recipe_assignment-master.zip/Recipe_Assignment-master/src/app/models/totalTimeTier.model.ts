export class TotalTimeTier {
  tier: string;
  display_tier: string;
}
