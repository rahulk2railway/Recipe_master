export class Nutrition {
  fiber: number;
  updated_at: Date;
  calories: number;
  carbohydrates: number;
  fat: number;
  protein: number;
  sugar: number;
}
