export class Unit {
  name: string;
  abbreviation: string;
  display_singular: string;
  display_plural: string;
  system: string;
}
