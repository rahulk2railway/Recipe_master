import { Results } from './results.model';

export class RecipeList {
  count: number;
  results: Array<Results>;
}
